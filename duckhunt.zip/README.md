Software realizado por Matt Surabian https://github.com/MattSurabian

Integrado con SGAME por Javier Álvarez Losada en el marco del Proyecto de Innovación Educativa "Creación, utilización y análisis de videojuegos educativos de diversos géneros" (IE22.6102) financiado por la Universidad Politécnica de Madrid.
